
document.addEventListener('DOMContentLoaded', function () {
    const openBtn = document.querySelector('.openbtn');
    const gNav = document.getElementById('g-nav');
    const circleBg = document.querySelector('.circle-bg');

    openBtn.addEventListener('click', function () {
        openBtn.classList.toggle('active');
        gNav.classList.toggle('panelactive');
        circleBg.classList.toggle('circleactive');
    });

    // メニュー内リンクをクリックしたら閉じる
    const navLinks = document.querySelectorAll('#g-nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            openBtn.classList.remove('active');
            gNav.classList.remove('panelactive');
            circleBg.classList.remove('circleactive');
        });
    });
});


document.addEventListener("DOMContentLoaded", () => {
    const fadeItems = document.querySelectorAll('.fadeUp');

    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                // 遅延をつけて順番に表示
                setTimeout(() => {
                    entry.target.classList.add('show');
                }, index * 150);
                obs.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    fadeItems.forEach(el => observer.observe(el));
});


